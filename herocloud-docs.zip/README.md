# HeroCloud Docs

This site explains every HeroCloud page: what works, what is not finished, and how it looks. It is built with Astro and Starlight.

## How to run it

1. Install once:

   ```bash
   pnpm install
   ```

2. Start the site:

   ```bash
   pnpm dev
   ```

3. Open http://127.0.0.1:4321 in your browser.

To stop it, press `Ctrl C` in the terminal.

## Other commands

| Command | What it does |
| --- | --- |
| `pnpm build` | Builds the final site into `dist/` |
| `pnpm preview` | Shows the built site on your computer |
| `node scripts/changelog.mjs` | Updates the Changelog page from the app's git history |
| `HC_PASSWORD=... node scripts/shoot.mjs` | Retakes all screenshots from the running app |

## Search

Press `Ctrl K` (or `/`) on any page to search. It works while running locally and in the built site.

## Where things are

- `src/content/docs/` has one page per feature, grouped by section.
- `public/shots/` has the screenshots.
- `shots/` says which app page each screenshot comes from.
- `CONVENTIONS.md` explains how to write a page.

## Screenshots

The screenshot script needs the HeroCloud app running at http://127.0.0.1:5180 and a login. Set the password in `HC_PASSWORD`, and optionally the email in `HC_EMAIL`.
